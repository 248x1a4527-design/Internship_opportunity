# Internship Opportunity Hub

Student app to browse, save and add internship opportunities.

## Features
- Search and domain filters
- Opportunity details and eligibility
- Add listing with validation
- Save/bookmark listings
- Provider state management
- SharedPreferences local persistence

The built-in listings are fictional demo records. There is no live internship API, vacancy verification or application submission. Verify real opportunities with employers.

## Run
```bash
flutter pub get
flutter analyze
flutter test
flutter run
```

## Release APK
```bash
flutter build apk --release
```
Output: `build/app/outputs/flutter-apk/app-release.apk`

## Screens
Explore, Details, Add Opportunity, Saved Internships.

## Team responsibilities
Add member names and actual feature ownership. Each member should make genuine commits and explain their work.

## Defect log
Record issues found during physical-device testing.
