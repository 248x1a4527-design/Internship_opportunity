import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:internship_opportunity_hub/main.dart';

void main(){
  testWidgets('Internship Hub shows app title',(tester)async{
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(const InternshipHubApp());
    await tester.pump();
    expect(find.text('Internship Hub'),findsOneWidget);
  });
}
