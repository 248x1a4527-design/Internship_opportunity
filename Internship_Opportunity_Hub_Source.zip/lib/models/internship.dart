class Internship {
  final String id, role, organization, domain, mode, duration, eligibility, description;
  final bool demo;
  const Internship({required this.id, required this.role, required this.organization,
    required this.domain, required this.mode, required this.duration,
    required this.eligibility, required this.description, this.demo = false});
  Map<String,dynamic> toJson() => {'id':id,'role':role,'organization':organization,
    'domain':domain,'mode':mode,'duration':duration,'eligibility':eligibility,
    'description':description,'demo':demo};
  factory Internship.fromJson(Map<String,dynamic> j) => Internship(
    id:j['id'], role:j['role'], organization:j['organization'], domain:j['domain'],
    mode:j['mode'], duration:j['duration'], eligibility:j['eligibility'],
    description:j['description'], demo:j['demo'] ?? false);
}
