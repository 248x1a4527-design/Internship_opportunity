import 'package:flutter/foundation.dart';
import '../models/internship.dart';
import '../services/storage_service.dart';

class InternshipProvider extends ChangeNotifier {
  final _storage=StorageService();
  List<Internship> _items=[]; Set<String> _saved={};
  bool isLoading=false; String? error;
  List<Internship> get items=>List.unmodifiable(_items);
  Set<String> get savedIds=>Set.unmodifiable(_saved);
  List<Internship> get savedItems=>_items.where((e)=>_saved.contains(e.id)).toList();
  Future<void> load() async {
    isLoading=true; error=null; notifyListeners();
    try { _items=await _storage.loadItems(); _saved=await _storage.loadSaved(); }
    catch (_) { error='Unable to load listings. Please retry.'; }
    finally { isLoading=false; notifyListeners(); }
  }
  List<Internship> filter(String q,String domain)=>_items.where((e)=>
    (domain=='All'||e.domain==domain) &&
    (q.trim().isEmpty||e.role.toLowerCase().contains(q.toLowerCase())||
      e.organization.toLowerCase().contains(q.toLowerCase()))).toList();
  Future<void> add({required String role,required String organization,required String domain,
    required String mode,required String duration,required String eligibility,required String description}) async {
    _items=[Internship(id:DateTime.now().microsecondsSinceEpoch.toString(),role:role.trim(),
      organization:organization.trim(),domain:domain,mode:mode,duration:duration.trim(),
      eligibility:eligibility.trim(),description:description.trim()),..._items];
    await _persist(); notifyListeners();
  }
  Future<void> toggleSaved(String id) async {
    if(_saved.contains(id)){_saved.remove(id);}else{_saved.add(id);}
    await _persist(); notifyListeners();
  }
  Future<void> _persist()=>_storage.save(_items,_saved);
}
