import 'package:flutter/material.dart';
import '../models/internship.dart';

class InternshipCard extends StatelessWidget {
  final Internship item; final bool saved; final VoidCallback onTap,onSave;
  const InternshipCard({super.key,required this.item,required this.saved,required this.onTap,required this.onSave});
  @override
  Widget build(BuildContext context)=>Card(child:ListTile(
    onTap:onTap, title:Text(item.role,style:const TextStyle(fontWeight:FontWeight.bold)),
    subtitle:Text('${item.organization}\n${item.domain} • ${item.mode} • ${item.duration}'),
    isThreeLine:true, trailing:IconButton(onPressed:onSave,
      icon:Icon(saved?Icons.bookmark:Icons.bookmark_border)),
  ));
}
