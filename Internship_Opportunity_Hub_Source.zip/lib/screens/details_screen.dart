import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/internship_provider.dart';

class DetailsScreen extends StatelessWidget {
  final String id; const DetailsScreen({super.key,required this.id});
  @override Widget build(BuildContext context){
    final p=context.watch<InternshipProvider>(); final found=p.items.where((e)=>e.id==id);
    if(found.isEmpty)return Scaffold(appBar:AppBar(),body:const Center(child:Text('Listing not found')));
    final e=found.first; final saved=p.savedIds.contains(id);
    return Scaffold(appBar:AppBar(title:const Text('Opportunity Details')),
      body:ListView(padding:const EdgeInsets.all(20),children:[
        Chip(label:Text(e.domain)),Text(e.role,style:Theme.of(context).textTheme.headlineSmall),
        Text(e.organization,style:Theme.of(context).textTheme.titleLarge),
        const SizedBox(height:16),Text('Mode: ${e.mode}'),Text('Duration: ${e.duration}'),
        const Divider(height:32),Text('Eligibility',style:Theme.of(context).textTheme.titleMedium),
        Text(e.eligibility),const SizedBox(height:18),
        Text('Description',style:Theme.of(context).textTheme.titleMedium),SelectableText(e.description),
        if(e.demo) const Padding(padding:EdgeInsets.only(top:16),child:Text('Fictional demo listing. Verify real opportunities independently.',style:TextStyle(color:Colors.deepOrange))),
        const SizedBox(height:20),OutlinedButton.icon(onPressed:()=>p.toggleSaved(id),
          icon:Icon(saved?Icons.bookmark:Icons.bookmark_border),label:Text(saved?'Remove saved':'Save internship')),
      ]));
  }
}
