import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/internship_provider.dart';
import '../widgets/internship_card.dart';
import 'details_screen.dart';

class SavedScreen extends StatelessWidget {
  const SavedScreen({super.key});
  @override Widget build(BuildContext context){
    final p=context.watch<InternshipProvider>(); final items=p.savedItems;
    return Scaffold(appBar:AppBar(title:const Text('Saved Internships')),
      body:items.isEmpty?const Center(child:Text('No saved internships yet.')):
      ListView(padding:const EdgeInsets.all(16),children:items.map((e)=>Padding(padding:const EdgeInsets.only(bottom:8),
        child:InternshipCard(item:e,saved:true,onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>DetailsScreen(id:e.id))),onSave:()=>p.toggleSaved(e.id)))).toList()));
  }
}
