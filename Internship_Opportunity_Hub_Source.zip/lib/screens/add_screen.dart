import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/internship_provider.dart';

class AddScreen extends StatefulWidget {
  const AddScreen({super.key});
  @override State<AddScreen> createState()=>_AddScreenState();
}
class _AddScreenState extends State<AddScreen>{
  final _key=GlobalKey<FormState>();
  final _role=TextEditingController(),_org=TextEditingController(),_duration=TextEditingController();
  final _eligibility=TextEditingController(),_description=TextEditingController();
  String _domain='Development',_mode='Remote'; bool _saving=false;
  @override void dispose(){_role.dispose();_org.dispose();_duration.dispose();_eligibility.dispose();_description.dispose();super.dispose();}
  Future<void> _submit()async{
    if(!_key.currentState!.validate()||_saving)return;
    setState(()=>_saving=true);
    try{await context.read<InternshipProvider>().add(role:_role.text,organization:_org.text,domain:_domain,mode:_mode,duration:_duration.text,eligibility:_eligibility.text,description:_description.text);
      if(mounted)Navigator.pop(context);
    }finally{if(mounted)setState(()=>_saving=false);}
  }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Add Internship')),
    body:Form(key:_key,child:ListView(padding:const EdgeInsets.all(18),children:[
      TextFormField(controller:_role,decoration:const InputDecoration(labelText:'Role title'),validator:(v)=>v==null||v.trim().length<3?'Enter a valid role':null),
      const SizedBox(height:10),
      TextFormField(controller:_org,decoration:const InputDecoration(labelText:'Organization'),validator:(v)=>v==null||v.trim().isEmpty?'Enter organization':null),
      const SizedBox(height:10),
      DropdownButtonFormField<String>(value:_domain,decoration:const InputDecoration(labelText:'Domain'),items:['Development','Programming','Design','Data'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>setState(()=>_domain=v??'Development')),
      const SizedBox(height:10),
      DropdownButtonFormField<String>(value:_mode,decoration:const InputDecoration(labelText:'Work mode'),items:['Remote','Hybrid','On-site'].map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(),onChanged:(v)=>setState(()=>_mode=v??'Remote')),
      const SizedBox(height:10),
      TextFormField(controller:_duration,decoration:const InputDecoration(labelText:'Duration'),validator:(v)=>v==null||v.trim().isEmpty?'Enter duration':null),
      const SizedBox(height:10),
      TextFormField(controller:_eligibility,minLines:2,maxLines:3,decoration:const InputDecoration(labelText:'Eligibility'),validator:(v)=>v==null||v.trim().length<5?'Add eligibility':null),
      const SizedBox(height:10),
      TextFormField(controller:_description,minLines:3,maxLines:6,decoration:const InputDecoration(labelText:'Description'),validator:(v)=>v==null||v.trim().length<10?'Enter at least 10 characters':null),
      const SizedBox(height:18),FilledButton(onPressed:_saving?null:_submit,child:Text(_saving?'Saving...':'Save opportunity')),
    ])));
  }
}
