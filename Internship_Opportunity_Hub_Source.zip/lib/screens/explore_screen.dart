import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/internship_provider.dart';
import '../widgets/internship_card.dart';
import 'details_screen.dart';
import 'add_screen.dart';
import 'saved_screen.dart';

class ExploreScreen extends StatefulWidget {
  const ExploreScreen({super.key});
  @override State<ExploreScreen> createState()=>_ExploreScreenState();
}
class _ExploreScreenState extends State<ExploreScreen>{
  final _search=TextEditingController(); String _domain='All';
  final _domains=['All','Development','Programming','Design','Data'];
  @override void dispose(){_search.dispose();super.dispose();}
  @override Widget build(BuildContext context){
    final p=context.watch<InternshipProvider>(); final list=p.filter(_search.text,_domain);
    return Scaffold(appBar:AppBar(title:const Text('Internship Hub'),actions:[
      IconButton(icon:const Icon(Icons.bookmarks_outlined),onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const SavedScreen())))
    ]),floatingActionButton:FloatingActionButton.extended(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AddScreen())),icon:const Icon(Icons.add),label:const Text('Add listing')),
    body:RefreshIndicator(onRefresh:p.load,child:ListView(padding:const EdgeInsets.all(16),children:[
      Text('Explore opportunities',style:Theme.of(context).textTheme.headlineSmall),
      const SizedBox(height:12),
      TextField(controller:_search,onChanged:(_)=>setState((){}),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Search role or organization')),
      const SizedBox(height:12),
      DropdownButtonFormField<String>(value:_domain,decoration:const InputDecoration(labelText:'Domain'),
        items:_domains.map((d)=>DropdownMenuItem(value:d,child:Text(d))).toList(),onChanged:(v)=>setState(()=>_domain=v??'All')),
      const SizedBox(height:12),
      if(p.isLoading&&p.items.isEmpty) const Center(child:CircularProgressIndicator())
      else if(p.error!=null&&p.items.isEmpty) Center(child:Column(children:[Text(p.error!),TextButton(onPressed:p.load,child:const Text('Retry'))]))
      else if(list.isEmpty) const Center(child:Padding(padding:EdgeInsets.all(30),child:Text('No internships found.')))
      else ...list.map((e)=>Padding(padding:const EdgeInsets.only(bottom:8),child:InternshipCard(item:e,saved:p.savedIds.contains(e.id),
        onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>DetailsScreen(id:e.id))),onSave:()=>p.toggleSaved(e.id)))),
    ])));
  }
}
