import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/internship.dart';

class StorageService {
  static const _items='internship_items_v1', _saved='internship_saved_v1';
  Future<List<Internship>> loadItems() async {
    final p=await SharedPreferences.getInstance(); final raw=p.getString(_items);
    if(raw==null) return _samples();
    try { return (jsonDecode(raw) as List).map((e)=>Internship.fromJson(Map<String,dynamic>.from(e))).toList(); }
    catch (_) { return _samples(); }
  }
  Future<Set<String>> loadSaved() async {
    final p=await SharedPreferences.getInstance(); return (p.getStringList(_saved)??[]).toSet();
  }
  Future<void> save(List<Internship> items, Set<String> saved) async {
    final p=await SharedPreferences.getInstance();
    await p.setString(_items,jsonEncode(items.map((e)=>e.toJson()).toList()));
    await p.setStringList(_saved,saved.toList());
  }
  List<Internship> _samples()=>const [
    Internship(id:'a1',role:'Flutter Developer Intern',organization:'Demo Digital Studio',domain:'Development',mode:'Hybrid',duration:'8 weeks',eligibility:'Sample: basic Dart and Flutter.',description:'Fictional sample listing for demonstrating the app. Verify real vacancies independently.',demo:true),
    Internship(id:'a2',role:'Python Automation Intern',organization:'Sample Tech Works',domain:'Programming',mode:'Remote',duration:'6 weeks',eligibility:'Sample: Python fundamentals.',description:'Fictional demo opportunity. No real vacancy is advertised.',demo:true),
    Internship(id:'a3',role:'UI Design Intern',organization:'Creative Demo Lab',domain:'Design',mode:'On-site',duration:'4 weeks',eligibility:'Sample: design basics and portfolio.',description:'Demo listing to illustrate internship categories and details.',demo:true),
    Internship(id:'a4',role:'Data Analysis Intern',organization:'Practice Analytics',domain:'Data',mode:'Remote',duration:'10 weeks',eligibility:'Sample: spreadsheet basics and SQL.',description:'Fictional sample. Confirm employer and terms before applying.',demo:true),
  ];
}
