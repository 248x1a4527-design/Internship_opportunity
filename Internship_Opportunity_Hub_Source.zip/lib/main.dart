import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'providers/internship_provider.dart';
import 'screens/explore_screen.dart';

void main() => runApp(ChangeNotifierProvider(
  create: (_) => InternshipProvider()..load(),
  child: const InternshipHubApp(),
));

class InternshipHubApp extends StatelessWidget {
  const InternshipHubApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Internship Hub', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF176B61)), useMaterial3: true),
    home: const ExploreScreen(),
  );
}
